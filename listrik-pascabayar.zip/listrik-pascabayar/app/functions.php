<?php 
	//koneksi ke database
	require_once "connect.php";

	//Fungsi dd($data): Untuk melakukan var_dump pada data yang diberikan dan kemudian menghentikan eksekusi skrip.
	function dd($data) {
		var_dump($data);
		die();
	}

	//Fungsi middleware($name, $options): Fungsi ini mengelola middleware autentikasi berdasarkan nama middleware yang diberikan 
	//(isLoggedIn, haveSession, isLoggedInPelanggan, isLoggedInPetugas, isLoggedInAdmin, dan isLoggedInAdminAndPetugas).
	//Setiap middleware memeriksa apakah pengguna telah login dan memiliki tingkat akses yang benar sebelum mengizinkan akses ke halaman tertentu.
	function middleware($name, $options = array()) {
		global $connect;

		if($name == "isLoggedIn") {
			if(!isset($_SESSION['Username'])) {
				session_destroy();
				echo "<script>alert('You must login for access this pages'); location.href='index.php?pages=login'</script>";
			} else {
				$data = $options['data'];				
				require_once $options['file'];
			}
		} else if($name == "haveSession") {
			if(isset($_SESSION['Username'])) {
				if($options['data']['Level'] == "Admin") {
					echo "<script>location.href='index.php?pages=home-admin';</script>";
				} else if($options['data']['Level'] == "Petugas") {
					echo "<script>location.href='index.php?pages=home-petugas';</script>";
				} else {
					echo "<script>location.href='index.php?pages=home-pelanggan';</script>";
				}
				echo "<script>location.href='index.php?pages=load'</script>";
			} else {
				$data = $options['data'];
				require_once $options['file'];
			}
		} else if($name == "isLoggedInPelanggan") {
			if(!isset($_SESSION['Username'])) {
				session_destroy();
				echo "<script>alert('You must login for access this pages'); location.href='index.php?pages=login'</script>";
			} else {
				if($options['data']['Level'] == "Pelanggan") {
					$data = $options['data'];							
					require_once $options['file'];
				} else {
					session_destroy();
				echo "<script>alert('Oops, this page is forbbiden.'); location.href='index.php?pages=login'</script>";
				}				
			}
		} else if($name == "isLoggedInPetugas") {
			if(!isset($_SESSION['Username'])) {
				session_destroy();
				echo "<script>alert('You must login for access this pages'); location.href='index.php?pages=login'</script>";
			} else {
				if($options['data']['Level'] == "Petugas") {
					$data = $options['data'];							
					require_once $options['file'];
				} else {
					session_destroy();
				echo "<script>alert('Oops, this page is forbbiden.'); location.href='index.php?pages=login'</script>";
				}				
			}
		} else if($name == "isLoggedInAdmin") {
			if(!isset($_SESSION['Username'])) {
				session_destroy();
				echo "<script>alert('You must login for access this pages'); location.href='index.php?pages=login'</script>";
			} else {
				if($options['data']['Level'] == "Admin") {
					$data = $options['data'];							
					require_once $options['file'];
				} else {
					session_destroy();
				echo "<script>alert('Oops, this page is forbbiden.'); location.href='index.php?pages=login'</script>";
				}				
			}
		} else if($name == "isLoggedInAdminAndPetugas") {
			if(!isset($_SESSION['Username'])) {
				session_destroy();
				echo "<script>alert('You must login for access this pages'); location.href='index.php?pages=login'</script>";
			} else {
				if($options['data']['Level'] == "Admin" || $options['data']['Level'] == "Petugas") {
					$data = $options['data'];							
					require_once $options['file'];
				} else {
					session_destroy();
				echo "<script>alert('Oops, this page is forbbiden.'); location.href='index.php?pages=login'</script>";
				}				
			}
		}
	}

	//Fungsi redirectWith($redirect, $array): Mengatur pesan sesi dan mengarahkan pengguna ke halaman tertentu.
	function redirectWith($redirect, $array = array()) {
		$_SESSION[$array['name']] = $array['message'];

		echo "<script>location.href='".$redirect."'</script>";
	}

	//Fungsi checkSession($name): Memeriksa apakah sesi dengan nama tertentu ada.
	function checkSession($name) {
		if(isset($_SESSION[$name])) {
			return true;
		} else {
			return false;
		}
	}

	//Fungsi getSession($name): Mengambil nilai dari sesi dengan nama tertentu jika ada.
	function getSession($name) {
		if(checkSession($name)) {
			return $_SESSION[$name];
		} else {
			return false;
		}
	}

	//Fungsi removeSession($name): Menghapus sesi dengan nama tertentu.
	function removeSession($name) {
		unset($_SESSION[$name]);
	}