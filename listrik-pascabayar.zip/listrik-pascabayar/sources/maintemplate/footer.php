		
		<script type="text/javascript">
			function deleteAlert(msg) {
				var confirm = window.confirm(msg);
				if(confirm) {
					return true;
				} else {
					return false;
				}
			}
		</script>
		</div>
	</body>
</html>