<?php 

	//Memeriksa apakah parameter NoTagihan ada di URL.
	if(isset($_GET['NoTagihan'])) {
		$NoTagihan = mysqli_real_escape_string($connect, $_GET['NoTagihan']);

		//Menjalankan query untuk memeriksa apakah NoTagihan yang diberikan ada di tabel tb_tagihan.
		$selectQuery = mysqli_query($connect, "SELECT * FROM tb_tagihan WHERE NoTagihan='$NoTagihan'");
		//Jika data ditemukan (mysqli_num_rows lebih dari 0), mengambil data tagihan dan menyimpan KodeTagihan dari hasil query.
		if(mysqli_num_rows($selectQuery) > 0) {
			$row = mysqli_fetch_assoc($selectQuery);
			$KodeTagihan = $row['KodeTagihan'];

			//Menjalankan query untuk memeriksa apakah ada pembayaran yang terkait dengan KodeTagihan tersebut di tabel tb_pembayaran.
			$deleteQueryFirst = mysqli_query($connect, "SELECT * FROM tb_pembayaran WHERE KodeTagihan='$KodeTagihan'");
			//Jika ada pembayaran yang terkait, penghapusan tagihan dibatalkan, dan pengguna akan dialihkan dengan pesan bahwa tagihan tidak bisa dihapus karena masih memiliki pembayaran
			if(mysqli_num_rows($deleteQueryFirst) > 0) {
				return redirectWith('index.php?pages=tagihan', [
							"name" => "have_pembayaran",
							"message" => "Anda tidak bisa menghapus tagihan ini dikarenakan masih memiliki pembayaran."
						]);
			//Jika tidak ada pembayaran terkait, menjalankan query untuk menghapus data dari tabel tb_tagihan.
			} else {				
				$deleteQuery = mysqli_query($connect, "DELETE FROM tb_tagihan WHERE NoTagihan='$NoTagihan'");
				if($deleteQuery) {
					//Jika penghapusan berhasil, pengguna akan dialihkan kembali ke halaman tagihan dengan pesan sukses.
					return redirectWith('index.php?pages=tagihan', [
							"name" => "success_delete_tagihan",
							"message" => "Tagihan berhasil di hapus."
						]);
				//Jika penghapusan gagal, pengguna akan dialihkan kembali dengan pesan kesalahan.
				} else {
					return redirectWith('index.php?pages=tagihan', [
							"name" => "failed_delete_tagihan",
							"message" => "Maaf, terjadi kesalahan pada server, silahkan menghubungi web administrator."
						]);		
				}
			}			
		} 
		//ika NoTagihan tidak ada di URL, atau NoTagihan yang diberikan tidak ditemukan di tabel tb_tagihan, tampilkan pesan "404 Not Found".
		else {
			echo "Kode Tarif Tidak Ditemukan";
		}

	} else {
		echo "404 Not Found";
	}