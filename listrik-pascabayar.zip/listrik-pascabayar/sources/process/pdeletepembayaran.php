<?php 

	//Input Validation and Security
	//Memeriksa apakah parameter KodePembayaran ada di URL.
	if(isset($_GET['KodePembayaran'])) {
		//Menggunakan mysqli_real_escape_string untuk menghindari injeksi SQL dengan membersihkan input dari karakter-karakter berbahaya.
		$KodePembayaran = mysqli_real_escape_string($connect, $_GET['KodePembayaran']);

		//Database Query and Existence Check
		//Menjalankan query untuk memeriksa apakah KodePembayaran yang diberikan ada di tabel tb_pembayaran.
		$selectQuery = mysqli_query($connect, "SELECT * FROM tb_pembayaran WHERE KodePembayaran='$KodePembayaran'");
		//Jika data ditemukan (mysqli_num_rows lebih dari 0), lanjutkan ke proses penghapusan.
		if(mysqli_num_rows($selectQuery) > 0) {

			//Data Deletion and Error Handling
			//Menjalankan query untuk menghapus data dari tabel tb_pembayaran.
			$deleteQuery = mysqli_query($connect, "DELETE FROM tb_pembayaran WHERE KodePembayaran='$KodePembayaran'");
			if($deleteQuery) {
				//Jika penghapusan berhasil, pengguna akan dialihkan kembali ke halaman pembayaran dengan pesan sukses.
				return redirectWith('index.php?pages=pembayaran', [
						"name" => "success_delete_pembayaran",
						"message" => "Pembayaran berhasil di hapus."
					]);
				//Jika penghapusan gagal, pengguna akan dialihkan kembali dengan pesan kesalahan.
				} else {
				return redirectWith('index.php?pages=pembayaran', [
						"name" => "failed_delete_pembayaran",
						"message" => "Maaf, mungkin terjadi kesalahan pada server, silahkan hubungin web administrator."
					]);		
				}
		//Error Messaging
		//ika KodePembayaran yang diberikan tidak ditemukan di tabel tb_pembayaran, tampilkan pesan bahwa kode tarif tidak ditemukan.
		} else {
			echo "Kode Tarif Tidak Ditemukan";
		}
	//Jika KodePembayaran tidak ada di URL, tampilkan pesan "404 Not Found".
	} else {
		echo "404 Not Found";
	}