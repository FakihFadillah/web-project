<?php 

	//Input Validation and Security

	//Kode ini memeriksa apakah parameter NoPelanggan ada dalam URL.
	if(isset($_GET['NoPelanggan'])) {
		//Menggunakan mysqli_real_escape_string untuk membersihkan input dari karakter khusus yang berpotensi digunakan dalam serangan injeksi SQL.
		$NoPelanggan = mysqli_real_escape_string($connect, $_GET['NoPelanggan']);

		//Database Query and Existence Check

		//Mengambil data pelanggan dari tabel tb_pelanggan berdasarkan NoPelanggan.
		$selectQuery = mysqli_query($connect, "SELECT * FROM tb_pelanggan WHERE NoPelanggan='$NoPelanggan'");
		//Memeriksa apakah pelanggan dengan NoPelanggan yang diberikan ada di database.
		if(mysqli_num_rows($selectQuery) > 0) {

		//Dependency Check
		//Memeriksa apakah pelanggan memiliki tagihan yang masih belum dibayar di tabel tb_tagihan.
		$selectQueryTagihan = mysqli_query($connect, "SELECT * FROM tb_tagihan WHERE NoPelanggan='$NoPelanggan'");
		if(mysqli_num_rows($selectQueryTagihan) > 0) {
			return redirectWith('index.php?pages=pelanggan', [
				//Jika pelanggan memiliki tagihan, maka proses penghapusan dibatalkan dan pengguna dialihkan kembali ke halaman pelanggan dengan pesan kesalahan.
					"name" => "failed_delete_pelanggan_tagihan",
					"message" => "Pelanggan yang anda hapus masih memiliki tagihan."
				]);
			} 

			//Data Deletion and Error Handling
			//Jika pelanggan tidak memiliki tagihan, sistem akan mencoba menghapus data pelanggan dari tabel tb_pelanggan.
			else {
				//Setelah itu, mencoba menghapus data pelanggan dari tabel tb_login (asumsi pelanggan juga memiliki akun login).
				$deleteQuery = mysqli_query($connect, "DELETE FROM tb_pelanggan WHERE NoPelanggan='$NoPelanggan'");
				if($deleteQuery) {
					$deleteQuerySecond = mysqli_query($connect, "DELETE FROM tb_login WHERE Username='$NoPelanggan'");
					if($deleteQuerySecond) {
						//Jika kedua operasi penghapusan berhasil, pengguna akan dialihkan kembali ke halaman pelanggan dengan pesan sukses.
						return redirectWith('index.php?pages=pelanggan', [
							"name" => "success_delete_pelanggan",
							"message" => "Pelanggan Berhasil Di Hapus"
						]);
						//Jika ada kesalahan pada salah satu operasi penghapusan, pengguna akan dialihkan kembali dengan pesan kesalahan.
					} else {
						return redirectWith('index.php?pages=pelanggan', [
							"name" => "failed_delete_pelanggan",
							"message" => "Maaf, Mungkin terjadi kesalahan pada server."
						]);
					}				
				} else {
					return redirectWith('index.php?pages=pelanggan', [
							"name" => "failed_delete_pelanggan",
							"message" => "Maaf, Mungkin terjadi kesalahan pada server."
						]);		
				}
			}			
		//Error Messaging
		//Jika NoPelanggan tidak ditemukan di tabel tb_pelanggan, menampilkan pesan bahwa kode tarif tidak ditemukan.
		} else {
			echo "Kode Tarif Tidak Ditemukan";
		}
	//Jika NoPelanggan tidak disediakan dalam URL, menampilkan pesan "404 Not Found".
	} else {
		echo "404 Not Found";
	}