<?php 

	//Memeriksa apakah metode request adalah POST untuk memastikan bahwa data yang diterima berasal dari form submission.
	if($_SERVER['REQUEST_METHOD'] === "POST") {

		//Input Validation and Security
		//Menggunakan mysqli_real_escape_string untuk membersihkan input dari karakter-karakter berbahaya dan mencegah SQL injection.
		$NoPelanggan 	= mysqli_real_escape_string($connect, $_POST['NoPelanggan']);
		$NoMeter		= mysqli_real_escape_string($connect, $_POST['NoMeter']);
		$KodeTarif		= mysqli_real_escape_string($connect, $_POST['KodeTarif']);
		$NamaLengkap	= mysqli_real_escape_string($connect, $_POST['NamaLengkap']);
		$Telp			= mysqli_real_escape_string($connect, $_POST['Telp']);
		$Alamat			= mysqli_real_escape_string($connect, $_POST['Alamat']);

		//Menjalankan query untuk memeriksa apakah NoPelanggan yang diberikan ada di tabel tb_pelanggan.
		$selectQuery	= mysqli_query($connect, "SELECT * FROM tb_pelanggan WHERE NoPelanggan='$NoPelanggan'");
		//Jika data ditemukan (mysqli_num_rows lebih dari 0), lanjut ke proses update.
		if(mysqli_num_rows($selectQuery) > 0) {

			//Menjalankan query untuk mengupdate NamaLengkap di tabel tb_login berdasarkan NoPelanggan.
			$updateQuery 	= mysqli_query($connect, "UPDATE tb_login SET NamaLengkap='$NamaLengkap' WHERE Username='$NoPelanggan'");
			if($updateQuery) {

				//Menjalankan query untuk mengupdate detail pelanggan di tabel tb_pelanggan.
				$updateQuerySecond = mysqli_query($connect, "UPDATE tb_pelanggan SET NoMeter='$NoMeter', KodeTarif='$KodeTarif', NamaLengkap='$NamaLengkap', Telp='$Telp', Alamat='$Alamat' WHERE NoPelanggan='$NoPelanggan'");
				if($updateQuerySecond) {
					//Jika update berhasil, pengguna akan dialihkan kembali ke halaman edit pelanggan dengan pesan sukses.
					return redirectWith('index.php?pages=editpelanggan&NoPelanggan='.$NoPelanggan, [
							"name" => "success_edit_pelanggan",
							"message" => "Pelanggan Berhasil Di Edit."
						]);
				} else {
					//Jika update gagal, pengguna akan dialihkan kembali dengan pesan kesalahan.
					return redirectWith('index.php?pages=editpelanggan&NoPelanggan='.$NoPelanggan, [
							"name" => "failed_edit_pelanggan",
							"message" => "Maaf, mungkin terjadi kesalahan pada server, silahkan kontak ke web administrator."
						]);
				}
			} else {
				//Jika update pada tabel tb_login gagal, pengguna akan dialihkan kembali dengan pesan kesalahan.
				return redirectWith('index.php?pages=editpelanggan&NoPelanggan='.$NoPelanggan, [
							"name" => "failed_edit_pelanggan",
							"message" => "Maaf, mungkin terjadi kesalahan pada server, silahkan kontak ke web administrator."
						]);
			}

		} else {

		}

	} 
	//Jika metode request bukan POST, tampilkan pesan bahwa metode GET tidak diizinkan.
	else {
		echo "Request Method <em>GET</em> Not Allowed";
	}