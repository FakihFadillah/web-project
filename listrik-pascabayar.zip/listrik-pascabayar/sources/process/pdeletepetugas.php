<?php 

	// Input Validation and Security
	if(isset($_GET['KodeLogin'])) {
		//Memeriksa apakah parameter KodeLogin ada di URL.
		$KodeLogin = mysqli_real_escape_string($connect, $_GET['KodeLogin']);
		//Menggunakan mysqli_real_escape_string untuk menghindari injeksi SQL dengan membersihkan input dari karakter-karakter berbahaya.
		
		//Database Query and Existence Check
		//Menjalankan query untuk memeriksa apakah KodeLogin yang diberikan ada di tabel tb_login.
		$selectQuery = mysqli_query($connect, "SELECT * FROM tb_login WHERE KodeLogin='$KodeLogin'");
		//Jika data ditemukan (mysqli_num_rows lebih dari 0), lanjutkan ke proses penghapusan.
		if(mysqli_num_rows($selectQuery) > 0) {

			//Data Deletion and Error Handling
			//Menjalankan query untuk menghapus data dari tabel tb_login.
			$deleteQuery = mysqli_query($connect, "DELETE FROM tb_login WHERE KodeLogin='$KodeLogin'");
			if($deleteQuery) {
				//Jika penghapusan berhasil, pengguna akan dialihkan kembali ke halaman petugas dengan pesan sukses.
				return redirectWith('index.php?pages=petugas', [
						"name" => "success_delete_petugas",
						"message" => "Petugas/Admin berhasil di hapus."
					]);
				//Jika penghapusan gagal, pengguna akan dialihkan kembali dengan pesan kesalahan.
				} else {
				return redirectWith('index.php?pages=petugas', [
						"name" => "failed_delete_petugas",
						"message" => "Maaf, mungkin terjadi kesalahan pada server. silahkan hubungi web administrator."
					]);		
				}

		//Jika KodeLogin yang diberikan tidak ditemukan di tabel tb_login, tampilkan pesan bahwa kode tarif tidak ditemukan.
		} else {
			echo "Kode Tarif Tidak Ditemukan";
		}
	//Jika KodeLogin tidak ada di URL, tampilkan pesan "404 Not Found".
	} else {
		echo "404 Not Found";
	}